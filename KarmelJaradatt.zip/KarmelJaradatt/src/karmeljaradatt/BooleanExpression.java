/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package karmeljaradatt;

/**
 *
 * @author karmel Jaradat
 */  
 
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

public class BooleanExpression extends JFrame {
    private JTextField expressionField;
    private DrawingPanel drawingPanel;

    public BooleanExpression() {
        setTitle("Boolean Expression Evaluator");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new FlowLayout());

        expressionField = new JTextField(20);
        JButton evaluateButton = new JButton("Evaluate");

        inputPanel.add(new JLabel("Enter Boolean Expression:"));
        inputPanel.add(expressionField);
        inputPanel.add(evaluateButton);

        drawingPanel = new DrawingPanel();
        drawingPanel.setBackground(Color.WHITE);

        add(inputPanel, BorderLayout.NORTH);
        add(drawingPanel, BorderLayout.CENTER);

        evaluateButton.addActionListener(new EvaluateButtonListener());

        setVisible(true);
    }

    private class EvaluateButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String expression = expressionField.getText();
            expression = expression.replaceAll("AND", "&")
                                   .replaceAll("OR", "|")
                                   .replaceAll("NOT", "!")
                                   .replaceAll("\\.", "&")
                                   .replaceAll("\\+", "|")
                                   .replaceAll("~", "!");
            Map<Character, Boolean> variableValues = new HashMap<>();

            try {
                for (char ch : expression.toCharArray()) {
                    if (Character.isLetter(ch) && !variableValues.containsKey(ch)) {
                        String value = JOptionPane.showInputDialog("Enter value for " + ch + " (true/false):");
                        if (value == null || (!value.equalsIgnoreCase("true") && !value.equalsIgnoreCase("false"))) {
                            throw new IllegalArgumentException("Invalid value for " + ch);
                        }
                        variableValues.put(ch, Boolean.parseBoolean(value));
                    }
                }

                boolean result = ExpressionEvaluator.evaluateBooleanExpression(expression, variableValues);
                JOptionPane.showMessageDialog(null, "The result of the expression is: " + result);

                drawingPanel.setExpression(expression, variableValues);
                drawingPanel.repaint();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Invalid expression: " + ex.getMessage());
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new BooleanExpression().setVisible(true));
    }
}
