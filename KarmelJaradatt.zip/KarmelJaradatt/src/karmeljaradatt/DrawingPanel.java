/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package karmeljaradatt;

/**
 *
 * @author karmel Jaradat
 */
import javax.swing.*;
import java.awt.*;
import java.util.Map;

public class DrawingPanel extends JPanel {
    private ExpressionEvaluator.TreeNode root;
    private Map<Character, Boolean> variableValues;
    private Image andGateImage;
    private Image orGateImage;
    private Image notGateImage;

    public DrawingPanel() {
         
        andGateImage = new ImageIcon("C:\\Users\\yaffa Jaradat\\Documents\\NetBeansProjects\\KarmelJaradatt\\src\\karmeljaradatt\\And.PNG").getImage();
        orGateImage = new ImageIcon("C:\\Users\\yaffa Jaradat\\Documents\\NetBeansProjects\\KarmelJaradatt\\src\\karmeljaradatt\\Or.PNG").getImage();
        notGateImage = new ImageIcon("C:\\Users\\yaffa Jaradat\\Documents\\NetBeansProjects\\KarmelJaradatt\\src\\karmeljaradatt\\Not.PNG").getImage();
         
        if (andGateImage == null || orGateImage == null || notGateImage == null) {
            JOptionPane.showMessageDialog(this, "Error loading images.");
        }
    }

    public void setExpression(String expression, Map<Character, Boolean> variableValues) {
        this.variableValues = variableValues;
        String postfix = ExpressionEvaluator.infixToPostfix(expression);
        this.root = ExpressionEvaluator.buildTree(postfix);
        repaint();  
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (root != null) {
            drawNode(g, root, 50, getHeight() / 2, 100);
        }
    }

    private void drawNode(Graphics g, ExpressionEvaluator.TreeNode node, int x, int y, int hGap) {
        if (node == null) return;

        if (Character.isLetter(node.value)) {
            drawVariable(g, node, x, y);
        } else {
            drawGate(g, node, x, y);
        }

        if (node.left != null) {
            g.drawLine(x + 40, y - 20, x, y);
            drawNode(g, node.left, x + hGap, y - 50, hGap / 2);
        }
        if (node.right != null) {
            g.drawLine(x + 40, y + 20, x, y);
            drawNode(g, node.right, x + hGap, y + 50, hGap / 2);
        }
    }

    private void drawVariable(Graphics g, ExpressionEvaluator.TreeNode node, int x, int y) {
        g.setColor(Color.BLUE);
        g.drawOval(x - 15, y - 15, 30, 30);
        g.drawString(String.valueOf(node.value), x - 5, y + 5);
        g.drawString(variableValues.get(node.value) ? "1" : "0", x - 5, y + 25);
    }

    private void drawGate(Graphics g, ExpressionEvaluator.TreeNode node, int x, int y) {
        g.setColor(Color.ORANGE);
        switch (node.value) {
            case '&':
                g.drawImage(andGateImage, x - 15, y - 15, this);
                break;
            case '|':
                g.drawImage(orGateImage, x - 15, y - 15, this);
                break;
            case '!':
                g.drawImage(notGateImage, x - 15, y - 15, this);
                break;
            default:
                throw new IllegalArgumentException("Invalid operator: " + node.value);
        }
        g.drawString(evaluateNode(node) ? "1" : "0", x - 5, y + 25);
    }

    private boolean evaluateNode(ExpressionEvaluator.TreeNode node) {
        if (node == null) return false;

        if (Character.isLetter(node.value)) {
            return variableValues.get(node.value);
        }

        boolean leftValue = evaluateNode(node.left);
        boolean rightValue = evaluateNode(node.right);

        switch (node.value) {
            case '&': return leftValue && rightValue;
            case '|': return leftValue || rightValue;
            case '!': return !rightValue;
            default: throw new IllegalArgumentException("Invalid operator: " + node.value);
        }
    }
}
