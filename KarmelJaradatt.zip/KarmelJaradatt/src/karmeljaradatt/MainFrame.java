/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package karmeljaradatt;

/**
 *
 * @author karmel Jaradat
 */  
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

public class MainFrame extends JFrame {
    private JTextField expressionField;
    private DrawingPanel drawingPanel;

    public MainFrame() {
        initComponents();
    }

    private void initComponents() {
        // Set up the frame
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Boolean Expression Visualizer");

        // Create components
        JLabel booleanexp = new JLabel("Boolean Expression :");
        expressionField = new JTextField(20);
        JButton drawButton = new JButton("Draw");

        // Create drawing panel
        drawingPanel = new DrawingPanel();
        drawingPanel.setPreferredSize(new Dimension(1200, 600)); // Increase the size for horizontal layout

        // Add action listener to button
        drawButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                onDrawButtonClicked();
            }
        });

        // Layout setup
        JPanel controlPanel = new JPanel();
        controlPanel.add(booleanexp);
        controlPanel.add(expressionField);
        controlPanel.add(drawButton);

        getContentPane().add(controlPanel, BorderLayout.NORTH);
        getContentPane().add(new JScrollPane(drawingPanel), BorderLayout.CENTER); // Add scroll pane for large drawings

        pack();
    }

    private void onDrawButtonClicked() {
        String expression = expressionField.getText().trim();
        // Provide a map of variable values
        Map<Character, Boolean> variableValues = new HashMap<>();
        variableValues.put('A', true);
        variableValues.put('B', false);
        variableValues.put('C', true);
        variableValues.put('D', false);

        drawingPanel.setExpression(expression, variableValues);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new MainFrame().setVisible(true);
            }
        });
    }
}
