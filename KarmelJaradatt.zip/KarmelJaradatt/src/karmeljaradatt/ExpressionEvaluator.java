/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package karmeljaradatt;

/**
 *
 * @author karmel Jaradat
 */ 

import java.util.Map;
import java.util.Stack;

public class ExpressionEvaluator {

    public static class TreeNode {
        char value;
        TreeNode left, right;

        TreeNode(char value) {
            this.value = value;
            this.left = this.right = null;
        }
    }

    public static TreeNode buildTree(String postfix) {
        Stack<TreeNode> stack = new Stack<>();
        for (char ch : postfix.toCharArray()) {
            TreeNode node = new TreeNode(ch);
            if (Character.isLetter(ch)) {
                stack.push(node);
            } else {
                if (ch == '!') {
                    node.right = stack.pop();
                } else {
                    node.right = stack.pop();
                    node.left = stack.pop();
                }
                stack.push(node);
            }
        }
        return stack.pop();
    }

    public static boolean evaluateBooleanExpression(String expression, Map<Character, Boolean> variableValues) {
        String postfix = infixToPostfix(expression);
        TreeNode root = buildTree(postfix);
        return evaluateTree(root, variableValues);
    }

    private static boolean evaluateTree(TreeNode node, Map<Character, Boolean> variableValues) {
        if (node == null) {
            return false;
        }
        if (Character.isLetter(node.value)) {
            return variableValues.get(node.value);
        }
        boolean leftValue = evaluateTree(node.left, variableValues);
        boolean rightValue = evaluateTree(node.right, variableValues);
        switch (node.value) {
            case '&':
                return leftValue && rightValue;
            case '|':
                return leftValue || rightValue;
            case '!':
                return !rightValue;
            default:
                throw new IllegalArgumentException("Invalid operator: " + node.value);
        }
    }

    public static String infixToPostfix(String expression) {
        StringBuilder result = new StringBuilder();
        Stack<Character> stack = new Stack<>();
        for (char ch : expression.toCharArray()) {
            if (Character.isLetter(ch)) {
                result.append(ch);
            } else if (ch == '(') {
                stack.push(ch);
            } else if (ch == ')') {
                while (!stack.isEmpty() && stack.peek() != '(') {
                    result.append(stack.pop());
                }
                if (!stack.isEmpty() && stack.peek() != '(') {
                    throw new IllegalArgumentException("Invalid expression");
                } else {
                    stack.pop();
                }
            } else {
                while (!stack.isEmpty() && precedence(ch) <= precedence(stack.peek())) {
                    result.append(stack.pop());
                }
                stack.push(ch);
            }
        }
        while (!stack.isEmpty()) {
            result.append(stack.pop());
        }
        return result.toString();
    }

    private static int precedence(char ch) {
        switch (ch) {
            case '|':
                return 1;
            case '&':
                return 2;
            case '!':
                return 3;
            default:
                return -1;
        }
    }
}
